const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());  // Enable CORS
app.use(express.json());

const users = [
  { id: 1, name: "Alice" },
  { id: 2, name: "Bob" }
];

app.get('/users', (req, res) => {
  res.json(users);
});

app.post('/users', (req, res) => {
  const { name } = req.body;
  const newUser = { id: users.length + 1, name };
  users.push(newUser);
  res.json({ message: "User added", user: newUser });
});

app.listen(5002, () => console.log("User service running on port 5002"));

